#!/usr/bin/python3
# -*- coding: utf-8 -*-

"""
@File: feature_selection.py
@Time: 2021/12/22 7:02 PM
@Author: genqiang_wu@163.com
@desc:
特征选择

"""
import numpy as np
import pandas as pd
from sklearn.linear_model import LassoCV

# 特征选择：使用随机森林
def features_selection_RF(train, label):
    X_train = np.array(train)
    y_train = np.array(label)

    from sklearn.ensemble import RandomForestClassifier
    forest = RandomForestClassifier(n_estimators=1000, random_state=0, n_jobs=-1)
    forest.fit(X_train, y_train)

    # feat_labels = train.columns[:]
    importances = forest.feature_importances_
    # indices = np.argsort(importances)[::-1]
    # for f in range(X_train.shape[1]):
    #     print("%2d) %-*s %f" % (f + 1, 30, feat_labels[indices[f]], importances[indices[f]]))
    # 筛选出重要性比较高的变量
    threshold = 0.0005
    X_selected = X_train[:, importances > threshold]

    return pd.DataFrame(X_selected)

# 特征选择：使用LASSO
def features_selection_LASSO(train, label, alpha=np.array([0.001])):
    # The alpha value range is 0.001, 0.002, 0.005, 0.01, 0.015, 0.02
    X_train = np.array(train)
    y_train = np.array(label)
    lassocv = LassoCV(cv=5, alphas=alpha).fit(X_train, y_train)
    x_lasso = lassocv.fit(X_train, y_train)  # Substituting alpha for dimensionality reduction
    importance = x_lasso.coef_ != 0
    new_data = X_train[:, importance]
    importance_list = []
    for i in range(len(importance)):
        if importance[i] == True:
            importance_list.append(i)
    # print(importance_list)
    return pd.DataFrame(new_data), importance_list

# 特征选择：使用LDA
def features_selection_LDA(train, label):
    # The alpha value range is 0.001, 0.002, 0.005, 0.01, 0.015, 0.02
    X_train = np.array(train)
    y_train = np.array(label)
    from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
    train = LDA(n_components=1).fit(train, label).transform(train)
    return pd.DataFrame(train)













# 特征选择：mRMR降维
def mRMR(train, label, max_d):
    from source_code.Feature_Selection.mRMR.mRMR import mRMR
    m = mRMR(train.shape[1])
    m.fit(train.values, label.values)
    m.transform(train.values)
    m.important_features.sort()
    train = train.iloc[:, m.important_features[:max_d]]
    train = pd.DataFrame(train)
    train.columns = range(train.shape[1])
    return train