#!/usr/bin/python3
# -*- coding: utf-8 -*-

"""
@File: BLS_Classifier.py
@Time: 2021/12/8 8:29 上午
@Author: genqiang_wu@163.com
@desc:
        SuccSitePred-BLS主要包括以下几个阶段：
        （1）分别从蛋白质序列中提取特征
        （2）将特征向量连接起来，形成7个组特征向量
        （3）用7个组特征构建7个BLS分类器（即BLS1、BLS2、BLS3、BLS4、BLS5、BLS6和BLS7）
        （4）使用堆叠集成分类器来整合来自上述7个BLS分类器的输出，在7个BLS分类器的输出上训练逻辑回归模型

"""

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold  # k折叠交叉验证

from my_work.NGly.Model.BLS import BroadLearningSystem
from my_work.NGly.Model import performance_evaluation, feature_selection

from sklearn.metrics import roc_auc_score


# 标准化数据: 不同的特征存在不同的量纲，为了消除量纲、数值差异
from sklearn.preprocessing import scale

# 忽略提醒
import warnings

from my_work.NGly.Model.imbalanced_data_processing import imbalanced_data_processing

warnings.filterwarnings("ignore")


def SuccSitePred_BLS(train, label):
    s = 0.9  # 1 # 收敛系数
    c = 2 ** (-30)  # 10 ** -10 # 正则化系数
    N1 = 3  # 映射层每个窗口内节点数
    N2 = 100  # 映射层窗口数
    N3 = 100  # 强化层节点数

    # 10折叠交叉验证
    k_fold = StratifiedKFold(n_splits=10, random_state=0, shuffle=True)

    # 定义10个矩阵，1行8列全0矩阵
    performance = np.zeros((10, 1, 8))

    # 用于存放训练集的预测
    train_y_pred = np.zeros(len(train))

    print('10折叠交叉验证: ')
    # enumerate() 函数用于将一个可遍历的数据对象(如列表、元组或字符串)组合为一个索引序列，同时列出数据和数据下标，一般用在 for 循环当中。
    for fold_, (train_index, validation_index) in enumerate(k_fold.split(train, label)):
        print("fold {} times".format(fold_ + 1))
        # 训练集、训练集标签
        X_train, y_train = np.array(train.iloc[train_index, :]), np.array(label.iloc[train_index])
        # 验证集、验证集标签
        X_validation, y_validation = np.array(train.iloc[validation_index, :]), np.array(label.iloc[validation_index])

        # 非平衡数据处理
        X_train, y_train = imbalanced_data_processing(X_train, y_train)

        # run BLS
        # y_pred = BroadLearningSystem.BLS(X_train, y_train, X_validation, s, c, N1, N2, N3)

        from sklearn import svm
        from sklearn.ensemble import RandomForestClassifier
        from sklearn.ensemble import GradientBoostingClassifier

        # run
        y_pred = svm.SVC(kernel="linear", C=1, gamma=1).fit(X_train, y_train).predict(X_validation)  # 跑SVM模型  svm.SVC(kernel="linear", C=1, gamma=1)
        # y_pred = RandomForestClassifier().fit(X_train, y_train).predict(X_validation)  # 跑RF模型
        # y_pred = GradientBoostingClassifier().fit(X_train, y_train).predict(X_validation)  # 跑gbm模型
        # y_pred = xgb().fit(X_train, y_train).predict(X_validation) # 跑XGboost模型

        # 存放训练集的预测
        train_y_pred[validation_index] = y_pred

        # 获取性能评价Sn, Sp, Acc, MCC, AUC, Precision, Recall, F1_Score
        Sn, Sp, Acc, MCC, Precision, Recall, F1_Score = performance_evaluation.show_performance(y_validation, y_pred)
        AUC = roc_auc_score(y_validation, y_pred)

        performance[fold_, 0, :] = np.array((Sn, Sp, Acc, MCC, AUC, Precision, Recall, F1_Score))
        print('Sn = %f, Sp = %f, Acc = %f, MCC = %f, AUC = %f, Precision = %f, Recall = %f, F1-Score = %f' % (
        Sn, Sp, Acc, MCC, AUC, Precision, Recall, F1_Score))

    print('SuccSitePred-BLS: ')
    performance_evaluation.print_performance(performance, 0)

    return train_y_pred

def generate_features():
    # 加载数据集
    # 加载数据 One-Hot
    x1 = pd.read_csv('../../One-Hot/train_One-Hot_sequences_encoded.csv')
    # 加载数据 n-gram
    x2 = pd.read_csv('../../CBOW/train_word_embedding_n_gram.csv')
    # AAF
    x3 = pd.read_csv('../../AAF_DWT/train_AAF_encoded.csv')
    # Chaos Game
    x4 = pd.read_csv('../../Chaos-Game/train_chaos_game_encooded.csv')
    # EBGW
    x5 = pd.read_csv('../../EBGW/train_EBGW.csv')

    x = pd.concat([x1, x2], axis=1)
    x.columns = np.arange(np.size(x, 1))
    train = x.iloc[:, :].astype('float64')

    train_data = pd.read_csv('../../train_data.csv')
    label = train_data['label']

    return train, label

if __name__ == '__main__':
    # 确定基准数据集
    train, label = generate_features()
    print(train.shape[1])

    # # 特征选择：使用Lasso
    # train, importance_list = feature_selection.features_selection_LASSO(train, label)
    # rain = feature_selection.features_selection_RF(train, label)
    # # 特征选择：使用LDA
    train = feature_selection.features_selection_LDA(train, label)
    print(train.shape[1])


    # # 标准化数据: 不同的特征存在不同的量纲，为了消除量纲、数值差异
    # train = scale(np.array(train))
    #
    # # ------ 以下部分：实现随机排序数据集 ---------
    # def get_shuffle(data, label, seed=27):
    #     # shuffle data
    #     np.random.seed(seed)
    #     index = [i for i in range(len(label))]
    #     np.random.shuffle(index)
    #     data = data[index]
    #     label = label[index]
    #     return pd.DataFrame(data), pd.DataFrame(label).iloc[:, 0]
    #
    # train, label = get_shuffle(np.array(train), np.array(label))

    # ------ 以上部分：实现随机排序数据集 ---------

    # 执行BLS宽度学习训练模型并预测
    bls_y_pred = SuccSitePred_BLS(train, label)
    print(bls_y_pred)
