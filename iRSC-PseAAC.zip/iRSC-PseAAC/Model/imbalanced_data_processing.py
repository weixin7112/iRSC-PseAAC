#!/usr/bin/python3
# -*- coding: utf-8 -*-

"""
@File: imbalanced_data_processing.py
@Time: 2021/12/22 7:06 PM
@Author: genqiang_wu@163.com
@desc: 

非平衡数据处理

"""
import numpy as np
import pandas as pd

# 非平衡数据处理
def imbalanced_data_processing(X_train, y_train):

    # 使用随机过采样处理非平衡问题
    # from imblearn.over_sampling import RandomOverSampler
    # ros = RandomOverSampler(random_state=0)
    # X_train, y_train = ros.fit_resample(X_train, y_train)

    # # 使用SMOTE处理非平衡问题
    # from imblearn.over_sampling import SMOTE
    # # Resample the minority class. You can change the strategy to 'auto' if you are not sure.
    # smote = SMOTE(sampling_strategy='minority', random_state=0)
    # # Fit the model to generate the data.
    # X_train, y_train = smote.fit_resample(X_train, y_train)

    # from imblearn.under_sampling import NearMiss
    # nm = NearMiss(version=1)
    # X_train, y_train = nm.fit_sample(X_train, y_train)

    # # 使用Borderline-SMOTE处理非平衡
    # from imblearn.over_sampling import BorderlineSMOTE
    # sm = BorderlineSMOTE(random_state=42, kind="borderline-1")
    # X_train, y_train = sm.fit_resample(X_train, y_train)

    # 下采样
    from imblearn.under_sampling import ClusterCentroids
    cc = ClusterCentroids(random_state=0)
    X_train, y_train = cc.fit_resample(X_train, y_train)

    # # 使用ADASYN处理非平衡
    # from imblearn.over_sampling import ADASYN
    # X_train, y_train = ADASYN().fit_resample(X_train, y_train)

    # # NearMiss-3：是一个两段式的算法。 首先，对于每一个负样本， 保留它们的M个近邻样本；接着, 那些到N个近邻样本平均距离最大的正样本将被选择。
    # from imblearn.under_sampling import NearMiss
    # nm = NearMiss(version=3)
    # X_train, y_train = nm.fit_resample(X_train, y_train)

    # # 使用最近邻算法来编辑(edit)数据集, 找出那些与邻居不太友好的样本然后移除
    # from imblearn.under_sampling import EditedNearestNeighbours
    # enn = EditedNearestNeighbours()
    # X_train, y_train = enn.fit_resample(X_train, y_train)

    # from imblearn.under_sampling import RepeatedEditedNearestNeighbours
    # renn = RepeatedEditedNearestNeighbours()
    # X_train, y_train = renn.fit_resample(X_train, y_train)

    # from imblearn.under_sampling import AllKNN
    # allknn = AllKNN()
    # X_train, y_train = allknn.fit_resample(X_train, y_train)

    # # 在数据上运用一种分类器, 然后将概率低于阈值的样本剔除掉
    # from lightgbm import LGBMClassifier
    # from imblearn.under_sampling import InstanceHardnessThreshold
    # iht = InstanceHardnessThreshold(random_state=0,
    #                                 estimator=LGBMClassifier())
    # X_train, y_train = iht.fit_resample(X_train, y_train)

    # # 过采样与下采样的结合
    # from imblearn.combine import SMOTEENN
    # smote_enn = SMOTEENN(random_state=0)
    # X_train, y_train = smote_enn.fit_resample(X_train, y_train)
    # from imblearn.combine import SMOTETomek
    # smote_tomek = SMOTETomek(random_state=0)
    # X_train, y_train = smote_tomek.fit_resample(X_train, y_train)

    return X_train, y_train