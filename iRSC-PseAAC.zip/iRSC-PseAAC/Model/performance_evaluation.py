#!/usr/bin/python3
# -*- coding: utf-8 -*-

"""
@File: performance_evaluation.py
@Time: 2021/12/22 6:45 PM
@Author: genqiang_wu@163.com
@desc:

工具包 by 吴跟强

"""

import itertools
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import average_precision_score
import pandas as pd
import math


# 性能评价指标
def show_performance(y_true, y_pred):

    # 定义tp, fp, tn, fn初始值
    TP, FP, FN, TN = 0, 0, 0, 0

    for i in range(len(y_true)):
        if y_true[i] == 1:
            if y_pred[i] >= 0.5:
                TP += 1
            else:
                FN += 1
        if y_true[i] == 0:
            if y_pred[i] >= 0.5:
                FP += 1
            else:
                TN += 1

    # 计算敏感性Sn
    Sn = TP / (TP + FN + 1e-06)
    # 计算特异性Sp
    Sp = TN / (FP + TN + 1e-06)
    # 计算Acc值
    Acc = (TP + TN) / len(y_true)
    # 计算MCC：马修斯相关系数是在混淆矩阵环境中建立二元分类器预测质量的最具信息性的单一分数
    MCC = ((TP * TN) - (FP * FN)) / np.sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN) + 1e-06)
    # presion：精准率
    Precision = TP / (TP + FP + 1e-06)
    # recall：召回率
    Recall = TP / (TP + FN + 1e-06)
    # F1-Score：precision和recall调和均值的2倍
    F1_Score = 2 * TP / (2 * TP + FP + FN + 1e-06)

    return Sn, Sp, Acc, MCC, Precision, Recall, F1_Score


def show_performance_test(y_test_true, y_test_pred):

    # 定义tp, fp, tn, fn初始值
    TP, FP, FN, TN = 0, 0, 0, 0

    for i in range(len(y_test_true)):
        if y_test_true[i] == 1:
            if y_test_true[i] >= 0.5:
                TP += 1
            else:
                FN += 1
        if y_test_true[i] == 0:
            if y_test_pred[i] >= 0.5:
                FP += 1
            else:
                TN += 1

    # 计算敏感性Sn
    Sn = TP / (TP + FN + 1e-06)
    # 计算特异性Sp
    Sp = TN / (FP + TN + 1e-06)
    # 计算Acc值
    Acc = (TP + TN) / len(y_test_pred)
    # 计算MCC：马修斯相关系数是在混淆矩阵环境中建立二元分类器预测质量的最具信息性的单一分数
    MCC = ((TP * TN) - (FP * FN)) / np.sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN) + 1e-06)
    # presion：精准率
    Precision = TP / (TP + FP + 1e-06)
    # recall：召回率
    Recall = TP / (TP + FN + 1e-06)
    # F1-Score：precision和recall调和均值的2倍
    F1_Score = 2 * TP / (2 * TP + FP + FN + 1e-06)

    return Sn, Sp, Acc, MCC, Precision, Recall, F1_Score



def print_performance(performance, row):
    print('Sn = %.2f%% ± %.2f%%' % (np.mean(performance[:, row, 0]) * 100, np.std(performance[:, row, 0]) * 100))
    print('Sp = %.2f%% ± %.2f%%' % (np.mean(performance[:, row, 1]) * 100, np.std(performance[:, row, 1]) * 100))
    print('Acc = %.2f%% ± %.2f%%' % (np.mean(performance[:, row, 2]) * 100, np.std(performance[:, row, 2]) * 100))
    print('MCC = %.4f ± %.4f' % (np.mean(performance[:, row, 3]), np.std(performance[:, row, 3])))
    print('AUC = %.4f ± %.4f' % (np.mean(performance[:, row, 4]), np.std(performance[:, row, 4])))
    print('Precision = %.2f%% ± %.2f%%' % (np.mean(performance[:, row, 5]) * 100, np.std(performance[:, row, 5]) * 100))
    print('Recall = %.2f%% ± %.2f%%' % (np.mean(performance[:, row, 6]) * 100, np.std(performance[:, row, 6]) * 100))
    print('F1-Score = %.4f ± %.4f' % (np.mean(performance[:, row, 7]), np.std(performance[:, row, 7])))

def print_performance_test(performance_test, row):
    print('Sn_test = %.2f%% ± %.2f%%' % (np.mean(performance_test[:, row, 0]) * 100, np.std(performance_test[:, row, 0]) * 100))
    print('Sp_test = %.2f%% ± %.2f%%' % (np.mean(performance_test[:, row, 1]) * 100, np.std(performance_test[:, row, 1]) * 100))
    print('Acc_test= %.2f%% ± %.2f%%' % (np.mean(performance_test[:, row, 2]) * 100, np.std(performance_test[:, row, 2]) * 100))
    print('MCC_test = %.4f ± %.4f' % (np.mean(performance_test[:, row, 3]), np.std(performance_test[:, row, 3])))
    print('AUC_test = %.4f ± %.4f' % (np.mean(performance_test[:, row, 4]), np.std(performance_test[:, row, 4])))
    print('Precision_test= %.2f%% ± %.2f%%' % (np.mean(performance_test[:, row, 5]) * 100, np.std(performance_test[:, row, 5]) * 100))
    print('Recall_test = %.2f%% ± %.2f%%' % (np.mean(performance_test[:, row, 6]) * 100, np.std(performance_test[:, row, 6]) * 100))
    print('F1-Score_test = %.4f ± %.4f' % (np.mean(performance_test[:, row, 7]), np.std(performance_test[:, row, 7])))


def categorical_probas_to_classes(p):
    return np.argmax(p, axis=1)


def to_categorical(y, nb_classes=None):
    '''Convert class vector (integers from 0 to nb_classes)
    to binary class matrix, for use with categorical_crossentropy.
    '''
    y = np.array(y, dtype='int')
    if not nb_classes:
        nb_classes = np.max(y) + 1
    Y = np.zeros((len(y), nb_classes))
    for i in range(len(y)):
        Y[i, y[i]] = 1.
    return Y


def plothistory(history):
    if 'val_acc' in history.history.keys():
        # summarize history for accuracy
        plt.plot(history.history['acc'])
        plt.plot(history.history['val_acc'])
        plt.title('model accuracy')
        plt.ylabel('accuracy')
        plt.xlabel('epoch')
        # plt.axis([800, 1000, 0, 1])
        plt.legend(['train', 'valid'], loc='lower right')
        plt.show()
        # summarize history for loss
        plt.plot(history.history['loss'])
        plt.plot(history.history['val_loss'])
        plt.title('model loss')
        plt.ylabel('loss')
        plt.xlabel('epoch')
        # plt.axis([800, 1000, 0, 1])
        plt.legend(['train', 'valid'], loc='upper left')
        plt.show()
    else:
        plt.plot(history.history['acc'])
        plt.plot(history.history['loss'])
        plt.title('Train acc/loss')
        plt.ylabel('acc/loss')
        plt.xlabel('epoch')
        plt.legend(['acc', 'loss'], loc='upper right')
        plt.show()


def plot_confusion_matrix(cm, classes,
                          normalize=False,
                          title='Confusion matrix',
                          cmap=plt.cm.Blues):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    print(cm)

    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, cm[i, j],
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')


def draw_roc(y_test, y_score):
    # Compute ROC curve and ROC area for each class
    n_classes = y_score.shape[-1]
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    num = 0
    if n_classes <= 1:
        fpr[0], tpr[0], _ = roc_curve(y_test[:, ], y_score[:, ])
        roc_auc[0] = auc(fpr[0], tpr[0])
        num = 0
    else:
        for i in range(n_classes):
            fpr[i], tpr[i], _ = roc_curve(y_test[:, i], y_score[:, i])
            roc_auc[i] = auc(fpr[i], tpr[i])
            num = n_classes - 1

    # Compute micro-average ROC curve and ROC area
    fpr["micro"], tpr["micro"], _ = roc_curve(y_test.ravel(), y_score.ravel())
    roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])

    plt.figure(figsize=(10, 10))

    # line-width
    lw = 2
    auc_score = roc_auc[num] * 100
    plt.plot(fpr[num], tpr[num], color='darkorange',
             lw=lw, label='ROC curve (area = %0.2f%%)' % auc_score)
    plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
    plt.xlim([0.0, 1.05])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver operating characteristic')
    plt.legend(loc="lower right")
    plt.show()


def draw_pr(y_test, y_score):
    # Compute ROC curve and ROC area for each class
    n_classes = y_score.shape[-1]
    precision = dict()
    recall = dict()
    average_precision = dict()
    num = 0
    if n_classes <= 1:
        precision[0], recall[0], _ = precision_recall_curve(y_test[:, ], y_score[:, ])
        average_precision[0] = average_precision_score(y_test[:, ], y_score[:, ])
        num = 0
    else:
        for i in range(n_classes):
            precision[i], recall[i], _ = precision_recall_curve(y_test[:, i], y_score[:, i])
            average_precision[i] = average_precision_score(y_test[:, i], y_score[:, i])
            num = n_classes - 1

    # Compute micro-average ROC curve and ROC area
    precision["micro"], recall["micro"], _ = precision_recall_curve(y_test.ravel(), y_score.ravel())
    average_precision["micro"] = average_precision_score(y_test, y_score, average="micro")

    # Plot Precision-Recall curve
    plt.figure(figsize=(10, 10))

    # line-width
    lw = 2
    pr_score = average_precision[num] * 100
    plt.plot(recall[i], precision[i], color='darkorange', lw=lw,
             label='Precision-recall curve (area = %0.2f%%)' % pr_score)
    plt.xlim([0.0, 1.05])
    plt.ylim([0.0, 1.05])
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('Precision-Recall curve')
    plt.legend(loc="lower right")
    plt.show()


def plot_embedding(X, y, title=None):
    # 将数据归一化到0-1之间
    x_min, x_max = np.min(X, 0), np.max(X, 0)
    X = (X - x_min) / (x_max - x_min)

    df = pd.DataFrame(dict(x=X[:, 0], y=X[:, 1], label=y))
    groups = df.groupby('label')

    plt.figure(figsize=(10, 10))
    plt.subplot(111)
    for name, group in groups:
        plt.scatter(group.x, group.y, c=plt.cm.Set1(name / 10.), label=name)
        #    plt.text(X[i, 0], X[i, 1], '.',
        #         color=plt.cm.Set1(labels[i] / 10.),
        #         fontdict={'weight': 'bold', 'size': 10})
    plt.xticks([]), plt.yticks([])
    plt.legend()
    if title is not None:
        plt.title(title)
    plt.show()

