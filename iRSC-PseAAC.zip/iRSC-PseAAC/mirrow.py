output_f = open("IRC‑Fuse_test_output.txt", 'a')

with open("IRC‑Fuse_test_output.txt", 'a') as file_1:
    with open('IRC‑Fuse_test.txt', encoding='utf8') as file:
        lines = file.readlines()
        for i in lines:
            line = list(i.strip())
            str_len = len(line)
            for j in range(str_len):
                if (line[j] == 'X'):
                    line[j] = line[str_len - j + 1]
            b = ''.join([str(i) for i in line])
            file_1.write(b + "\n")