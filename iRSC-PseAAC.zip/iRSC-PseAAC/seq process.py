import pandas as pd
import numpy as np
train = pd.read_csv('IRC‑Fuse_train_output.txt', sep='\\t', header=None)
train.columns = ['label', 'sequence']
train.to_csv('train_data.csv', index=False)

test = pd.read_csv('IRC‑Fuse_test_output.txt', sep='\\t', header=None)
test.columns = ['label', 'sequence']
test.to_csv('test_data.csv', index=False)
