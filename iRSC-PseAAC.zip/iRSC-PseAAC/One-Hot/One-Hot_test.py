#!/usr/bin/python3
# -*- coding: utf-8 -*-

"""
@File: One-Hot.py
@Time: 2022/1/14 5:23 PM
@Author: genqiang_wu@163.com
@desc: 

"""

import pandas as pd
import numpy as np
import re

def one_hot_amino_acid(base_sequence, sequences):
    sequence_to_integer = dict((i, c) for c, i in enumerate(base_sequence))
    one_hot_encoded = []
    for seq in sequences:
        # seq = re.sub('-', 'X', seq)
        # seq = re.sub(r'[^ACDEFGHIKLMNPQRSTVWY]', 'X', seq)
        integer_encoded = [sequence_to_integer[index] for index in seq]
        one_hot_encoded_single = []
        for value in integer_encoded:
            seq = [0 for x in range(len(base_sequence))]
            seq[value] = 1
            # 末尾追加seq
            one_hot_encoded_single.extend(seq)
        one_hot_encoded.append(one_hot_encoded_single)

    return one_hot_encoded

# base_sequence = 'ACDEFGHIKLMNPQRSTVWYX'
base_sequence = 'ACDEFGHIKLMNPQRSTVWY'

# 1.read the dataset
test_data = pd.read_csv(r'../test_data.csv')
test = test_data['sequence']
print(one_hot_amino_acid(base_sequence, test))
one_hot = pd.DataFrame(one_hot_amino_acid(base_sequence, test))
one_hot.to_csv('test_One-Hot_sequences_encoded.csv', index = False, mode = "w+")