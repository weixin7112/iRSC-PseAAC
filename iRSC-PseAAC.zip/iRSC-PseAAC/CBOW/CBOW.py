#!/usr/bin/python3
# -*- coding: utf-8 -*-

"""
@File: CBOW.py
@Time: 2022/1/14 5:24 PM
@Author: genqiang_wu@163.com
@desc: 

"""

'''CBOW获取词嵌入向量'''
# 引入 word2vec
from gensim.models import word2vec
from gensim.models.callbacks import CallbackAny2Vec
import pandas as pd
import numpy as np
import re
import os
from tqdm import tqdm

# n-gram切词
def get_n_gram_text(sequences, max_n_gram):

    for i in range(2, max_n_gram + 1):
        file_name = 'wordbook_{}_gram.txt'.format(i)
        word = []
        for seq in tqdm(sequences):
            text = ''
            for j in range(len(seq) - i + 1):
                # word.append(seq[j:j+i])
                if j != len(seq) - i:
                    text += seq[j:j+i] + ' '
                else:
                    text += seq[j:j+i]
            word.append(text)
        wordbook = pd.DataFrame(word)
        wordbook.to_csv(file_name, index = False, header = None)


# 构建模型
def train_model():
    # 引入数据集，切分过的词汇
    sentences = word2vec.Text8Corpus(r'wordbook_2_gram.txt')
    word2vec.Word2Vec(sentences, seed=0, min_count=0, vector_size=100, window=5, compute_loss=True, epochs=100, workers=8,
                      callbacks=[EpochLogger("l2")])
    sentences = word2vec.Text8Corpus(r'wordbook_3_gram.txt')
    word2vec.Word2Vec(sentences, seed=0, min_count=0, vector_size=100, window=5, compute_loss=True, epochs=100, workers=8,
                      callbacks=[EpochLogger("l3")])
    # sentences = word2vec.Text8Corpus(r'wordbook_4_gram.txt')
    # word2vec.Word2Vec(sentences, min_count=0, vector_size=100, window=5, compute_loss=True, epochs=100, workers=8,
    #                   callbacks=[EpochLogger("l4")])


def get_CBOW_vector(file_path, model):
    f = open(file_path, 'r')
    word_book = f.readlines()
    f.close()
    count = 0
    vector = None
    for line in tqdm(word_book):
        line = line.split()
        single_vector = np.mean(model[line], axis=0, keepdims=True)

        if count == 0:
            vector = single_vector
            count += 1
        else:
            vector = np.r_[vector, single_vector]
    return vector


def merge_features():
    train_model()
    print("extract cbow features...")
    if os.path.exists(r'l2.model'):
        model_1 = word2vec.Word2Vec.load(r'l2.model')
    else:
        model_1 = word2vec.Word2Vec.load(r'last_l2.model')
    if os.path.exists(r'l3.model'):
        model_2 = word2vec.Word2Vec.load(r'l3.model')
    else:
        model_2 = word2vec.Word2Vec.load(r'last_l3.model')
    # if os.path.exists(r'l4.model'):
    #     model_3 = word2vec.Word2Vec.load(r'l4.model')
    # else:
    #     model_3 = word2vec.Word2Vec.load(r'last_l4.model')
    feautures_1 = get_CBOW_vector(r'wordbook_2_gram.txt', model_1.wv)
    feautures_2 = get_CBOW_vector(r'wordbook_3_gram.txt', model_2.wv)
    # feautures_3 = get_CBOW_vector(r'wordbook_4_gram.txt', model_3.wv)
    # CBOW_features = np.concatenate([feautures_1, feautures_2, feautures_3], axis=1)
    CBOW_features = np.concatenate([feautures_1, feautures_2], axis=1)
    return CBOW_features


class EpochLogger(CallbackAny2Vec):
    def __init__(self, name):
        self.epoch = 1
        self.losses = []
        self.previous_losses = 0
        self.add_losses = []
        self.name = name

    def on_epoch_end(self, model):
        loss = model.get_latest_training_loss()
        self.losses.append(loss)
        self.epoch += 1
        self.add_losses.append(loss - self.previous_losses)
        self.previous_losses = loss
        if self.epoch > 2:
            if self.add_losses[-1] == 0 and self.add_losses[-2] != 0:
                path = r"./" + os.sep + "{}.model".format(self.name)
                model.save(path)

    def on_train_end(self, model):
        if self.add_losses[-1] == 0:
            pass
        else:
            path = r"./" + os.sep + "last_{}.model".format(self.name)
            model.save(path)


if __name__ == '__main__':
    # 1.read the dataset
    train_data = pd.read_csv(r'../train_data.csv')        #读取路径
    sequences = train_data['sequence']
    new_sequences = []
    for seq in tqdm(sequences, desc='sequences n-gram: '):
        # seq = re.sub('-', 'X', seq)
        new_sequences.append(re.sub(r'[^ACDEFGHIKLMNPQRSTVWYX]', 'X', seq))
    # 调用n-gram进行分词，最大分词为4
    get_n_gram_text(new_sequences, 3)  
    features = merge_features()
    pd.DataFrame(features).to_csv('train_word_embedding_n_gram.csv', index=False)